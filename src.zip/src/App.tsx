import { useState } from "react";
import {
  Check,
  X,
  FileText,
  CalendarCheck,
  Sparkles,
  Database,
  ChevronDown,
  Send,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import dashboardImg from "@/assets/dashboard.jpg";
import aiChatImg from "@/assets/ai-chat.jpg";
import phonesImg from "@/assets/phones-analytics.jpg";
import foundersImg from "@/assets/founders.jpg";

const API_URL = import.meta.env.VITE_API_URL || "https://clinvert.com/api/contacto";

// ─── Helpers ────────────────────────────────────────────────────────────────

function SectionTag({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{
        display: "inline-block",
        backgroundColor: "var(--card)",
        color: "var(--muted-foreground)",
        border: "1px solid var(--border)",
        padding: "6px 12px",
        borderRadius: "4px",
        fontSize: "10px",
        letterSpacing: "0.2em",
        textTransform: "uppercase",
        fontWeight: 500,
      }}
    >
      {children}
    </span>
  );
}

function CTAButton({ children = "AGENDA TU SESIÓN DE CRECIMIENTO", style }: { children?: React.ReactNode; style?: React.CSSProperties }) {
  const scrollToForm = () => {
    const el = document.getElementById("contacto");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  return (
    <button
      onClick={scrollToForm}
      style={{
        backgroundColor: "var(--primary)",
        color: "var(--primary-foreground)",
        fontWeight: "bold",
        letterSpacing: "0.05em",
        borderRadius: "9999px",
        padding: "16px 32px",
        fontSize: "14px",
        textTransform: "uppercase",
        boxShadow: "var(--shadow-glow)",
        border: "none",
        cursor: "pointer",
        transition: "all 0.2s",
        ...style,
      }}
      onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.02)")}
      onMouseLeave={e => (e.currentTarget.style.transform = "scale(1)")}
    >
      {children}
    </button>
  );
}

// ─── Contact Form ────────────────────────────────────────────────────────────

interface FormData { nombre: string; email: string; telefono: string; mensaje: string; }
interface FormErrors { nombre?: string; email?: string; telefono?: string; mensaje?: string; }
type FormStatus = "idle" | "loading" | "success" | "error";

function validate(d: FormData): FormErrors {
  const e: FormErrors = {};
  if (!d.nombre.trim()) e.nombre = "El nombre es obligatorio.";
  if (!d.email.trim()) e.email = "El email es obligatorio.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) e.email = "Email inválido.";
  if (!d.telefono.trim()) e.telefono = "El teléfono es obligatorio.";
  if (!d.mensaje.trim()) e.mensaje = "Cuéntanos cómo podemos ayudarte.";
  return e;
}

function ContactForm() {
  const [form, setForm] = useState<FormData>({ nombre: "", email: "", telefono: "", mensaje: "" });
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<FormStatus>("idle");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(p => ({ ...p, [name]: value }));
    if (errors[name as keyof FormErrors]) setErrors(p => ({ ...p, [name]: undefined }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate(form);
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setStatus("loading");
    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setStatus("success");
      setForm({ nombre: "", email: "", telefono: "", mensaje: "" });
    } catch {
      setStatus("error");
    }
  };

  const inputStyle = (hasError?: string): React.CSSProperties => ({
    width: "100%",
    backgroundColor: "var(--input)",
    border: `1px solid ${hasError ? "var(--destructive)" : "var(--border)"}`,
    borderRadius: "8px",
    padding: "12px 16px",
    fontSize: "14px",
    color: "var(--foreground)",
    outline: "none",
    transition: "border-color 0.2s",
  });

  return (
    <section id="contacto" style={{ padding: "96px 24px", backgroundColor: "oklch(0.19 0.025 270 / 0.4)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)", scrollMarginTop: "32px" }}>
      <div style={{ maxWidth: "640px", margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "48px" }}>
          <SectionTag>HABLA CON NOSOTROS</SectionTag>
          <h2 style={{ marginTop: "32px", fontSize: "clamp(28px, 5vw, 36px)", fontWeight: "bold", lineHeight: 1.2 }}>
            Agenda Tu <span style={{ color: "var(--primary)" }}>Sesión de Crecimiento</span>
          </h2>
          <p style={{ marginTop: "16px", color: "var(--muted-foreground)" }}>
            Cuéntanos sobre tu clínica y te mostramos cómo Clinvert IA puede transformar tu proceso de ventas en menos de 10 días.
          </p>
        </div>

        {status === "success" ? (
          <div style={{ backgroundColor: "var(--card)", border: "1px solid var(--primary)", borderRadius: "16px", padding: "48px", textAlign: "center", boxShadow: "var(--shadow-glow)" }}>
            <CheckCircle2 style={{ width: 64, height: 64, color: "var(--primary)", margin: "0 auto 24px" }} />
            <h3 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "12px" }}>¡Mensaje recibido!</h3>
            <p style={{ color: "var(--muted-foreground)" }}>Nos pondremos en contacto contigo en las próximas horas para coordinar tu sesión de crecimiento.</p>
            <button onClick={() => setStatus("idle")} style={{ marginTop: "32px", color: "var(--primary)", fontSize: "14px", background: "none", border: "none", cursor: "pointer", textDecoration: "underline" }}>
              Enviar otro mensaje
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate style={{ backgroundColor: "var(--card)", border: "1px solid var(--border)", borderRadius: "16px", padding: "40px", boxShadow: "var(--shadow-elegant)" }}>
            {[
              { id: "nombre", label: "Nombre completo", type: "text", placeholder: "Juan García" },
              { id: "email", label: "Correo electrónico", type: "email", placeholder: "juan@miclinica.com" },
              { id: "telefono", label: "Teléfono / WhatsApp", type: "tel", placeholder: "+57 300 000 0000" },
            ].map(({ id, label, type, placeholder }) => (
              <div key={id} style={{ marginBottom: "24px" }}>
                <label htmlFor={id} style={{ display: "block", fontSize: "14px", fontWeight: 500, marginBottom: "8px" }}>
                  {label} <span style={{ color: "var(--primary)" }}>*</span>
                </label>
                <input
                  id={id} name={id} type={type}
                  value={form[id as keyof FormData]}
                  onChange={handleChange}
                  placeholder={placeholder}
                  style={inputStyle(errors[id as keyof FormErrors])}
                  onFocus={e => (e.target.style.borderColor = "var(--primary)")}
                  onBlur={e => (e.target.style.borderColor = errors[id as keyof FormErrors] ? "var(--destructive)" : "var(--border)")}
                />
                {errors[id as keyof FormErrors] && (
                  <p style={{ marginTop: "6px", fontSize: "12px", color: "var(--destructive)" }}>{errors[id as keyof FormErrors]}</p>
                )}
              </div>
            ))}

            <div style={{ marginBottom: "24px" }}>
              <label htmlFor="mensaje" style={{ display: "block", fontSize: "14px", fontWeight: 500, marginBottom: "8px" }}>
                ¿Cómo podemos ayudarte? <span style={{ color: "var(--primary)" }}>*</span>
              </label>
              <textarea
                id="mensaje" name="mensaje" rows={4}
                value={form.mensaje} onChange={handleChange}
                placeholder="Cuéntanos sobre tu clínica, cuántos leads manejas al mes, qué retos tienes..."
                style={{ ...inputStyle(errors.mensaje), resize: "none" }}
                onFocus={e => (e.target.style.borderColor = "var(--primary)")}
                onBlur={e => (e.target.style.borderColor = errors.mensaje ? "var(--destructive)" : "var(--border)")}
              />
              {errors.mensaje && <p style={{ marginTop: "6px", fontSize: "12px", color: "var(--destructive)" }}>{errors.mensaje}</p>}
            </div>

            {status === "error" && (
              <div style={{ marginBottom: "24px", padding: "12px 16px", backgroundColor: "oklch(0.6 0.2 25 / 0.1)", border: "1px solid oklch(0.6 0.2 25 / 0.3)", borderRadius: "8px", fontSize: "14px", color: "var(--destructive)" }}>
                Hubo un error al enviar. Intenta de nuevo o escríbenos a <a href="mailto:info@clinvertia.com" style={{ color: "var(--destructive)" }}>info@clinvertia.com</a>
              </div>
            )}

            <button
              type="submit" disabled={status === "loading"}
              style={{
                width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: "12px",
                backgroundColor: status === "loading" ? "oklch(0.82 0.13 85 / 0.6)" : "var(--primary)",
                color: "var(--primary-foreground)", fontWeight: "bold", letterSpacing: "0.05em",
                borderRadius: "9999px", padding: "16px 32px", fontSize: "14px", textTransform: "uppercase",
                boxShadow: "var(--shadow-glow)", border: "none",
                cursor: status === "loading" ? "not-allowed" : "pointer", transition: "all 0.2s",
              }}
            >
              {status === "loading" ? (
                <><Loader2 style={{ width: 16, height: 16, animation: "spin 1s linear infinite" }} />Enviando...</>
              ) : (
                <><CalendarCheck style={{ width: 16, height: 16 }} />Agendar Mi Sesión Gratuita<Send style={{ width: 16, height: 16 }} /></>
              )}
            </button>
            <p style={{ textAlign: "center", fontSize: "12px", color: "var(--muted-foreground)", marginTop: "16px" }}>
              Sin compromiso · Te respondemos en menos de 24 horas
            </p>
          </form>
        )}
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </section>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <div style={{ minHeight: "100vh", backgroundColor: "var(--background)", color: "var(--foreground)" }}>

      {/* NAV */}
      <header style={{ display: "flex", justifyContent: "center", padding: "32px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div style={{ width: 28, height: 28, borderRadius: "50%", backgroundColor: "oklch(0.82 0.13 85 / 0.2)", border: "1px solid var(--primary)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: "var(--primary)", fontSize: "12px", fontWeight: "bold" }}>C</span>
          </div>
          <span style={{ fontWeight: 600, letterSpacing: "0.2em", fontSize: "14px" }}>CLINVERT IA</span>
        </div>
      </header>

      {/* HERO */}
      <section style={{ padding: "32px 24px 80px", textAlign: "center", backgroundImage: "var(--gradient-hero)", position: "relative", overflow: "hidden" }}>
        <div style={{ maxWidth: "896px", margin: "0 auto" }}>
          <SectionTag>EL AGENTE IA #1 PARA CLÍNICAS ESTÉTICAS</SectionTag>
          <h1 style={{ marginTop: "32px", fontSize: "clamp(32px, 6vw, 60px)", fontWeight: "bold", lineHeight: 1.15, letterSpacing: "-0.02em" }}>
            Responder rápido ya no es suficiente… si no conviertes tus chats en citas,{" "}
            <span style={{ color: "var(--primary)" }}>estás perdiendo dinero.</span>
          </h1>
          <p style={{ marginTop: "24px", color: "var(--muted-foreground)", maxWidth: "640px", margin: "24px auto 0", lineHeight: 1.7, fontSize: "clamp(15px, 2vw, 18px)" }}>
            Nuestro agente con IA envía cotizaciones, agenda automáticamente, informa sobre tus tratamientos y crea oportunidades en tu CRM — todo mientras tú atiendes a tus pacientes.
          </p>
          <div style={{ marginTop: "40px" }}><CTAButton /></div>
          <div style={{ marginTop: "64px", maxWidth: "768px", margin: "64px auto 0", borderRadius: "12px", overflow: "hidden", border: "1px solid var(--border)", boxShadow: "var(--shadow-elegant)" }}>
            <img src={dashboardImg} alt="Panel del agente IA" style={{ width: "100%", display: "block" }} />
          </div>
        </div>
      </section>

      {/* PROBLEMA */}
      <section style={{ padding: "96px 24px", maxWidth: "1024px", margin: "0 auto", textAlign: "center" }}>
        <SectionTag>SI TIENES UNA CLÍNICA ESTÉTICA, PROBABLEMENTE TE PASA QUE...</SectionTag>
        <h2 style={{ marginTop: "32px", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "bold", lineHeight: 1.3 }}>
          Cada minuto que tardas en responder, es un paciente que se va con tu competencia.
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "24px", marginTop: "56px", textAlign: "left" }}>
          <div style={{ backgroundColor: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", padding: "32px" }}>
            <h3 style={{ color: "var(--destructive)", fontWeight: "bold", fontSize: "18px", marginBottom: "20px" }}>¿Te suena familiar?</h3>
            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "16px" }}>
              {["Los leads preguntan precios de noche y los respondes al día siguiente.", "Pasas horas armando cotizaciones manuales tratamiento por tratamiento.", "No tienes registro claro de quién pidió qué ni en qué etapa va.", "Tu equipo agenda mal, dobla horarios o se le escapan citas.", "Muchos contactos se pierden porque nadie hace seguimiento."].map(t => (
                <li key={t} style={{ display: "flex", gap: "12px", fontSize: "14px" }}>
                  <X style={{ width: 20, height: 20, color: "var(--destructive)", flexShrink: 0, marginTop: 2 }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
          <div style={{ backgroundColor: "var(--card)", border: "1px solid var(--primary)", borderRadius: "12px", padding: "32px", boxShadow: "var(--shadow-glow)" }}>
            <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "18px", marginBottom: "20px" }}>Imagina poder...</h3>
            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "16px" }}>
              {["Responder en segundos con cotizaciones personalizadas las 24 horas.", "Agendar citas directamente en tu calendario sin intervención humana.", "Resolver dudas sobre cada tratamiento con información precisa de tu clínica.", "Ver cada conversación convertida en una oportunidad activa en tu CRM."].map(t => (
                <li key={t} style={{ display: "flex", gap: "12px", fontSize: "14px" }}>
                  <Check style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0, marginTop: 2 }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p style={{ marginTop: "48px", color: "var(--muted-foreground)", fontStyle: "italic" }}>¿Listo para activarlo?</p>
        <div style={{ marginTop: "16px" }}><CTAButton /></div>
      </section>

      {/* 4 PILARES */}
      <section style={{ padding: "96px 24px", backgroundColor: "oklch(0.19 0.025 270 / 0.4)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: "1152px", margin: "0 auto", textAlign: "center" }}>
          <SectionTag>UN AGENTE IA QUE HACE EL TRABAJO DE TODO TU EQUIPO COMERCIAL</SectionTag>
          <h2 style={{ marginTop: "32px", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "bold", lineHeight: 1.3, maxWidth: "768px", margin: "32px auto 0" }}>
            Cuatro Tareas Críticas, Automatizadas Por Una Sola IA Entrenada Para Tu Clínica
          </h2>
          <p style={{ marginTop: "16px", color: "var(--muted-foreground)" }}>Así reemplazamos horas de trabajo manual con segundos de respuesta inteligente</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "24px", marginTop: "56px", textAlign: "left" }}>
            {[
              { Icon: FileText, title: "Envía cotizaciones al instante", desc: "Genera y manda cotizaciones personalizadas según el tratamiento que pregunte el paciente, con tus precios y condiciones reales." },
              { Icon: CalendarCheck, title: "Agenda automáticamente", desc: "Conecta con tu calendario, sugiere horarios disponibles y confirma la cita sin que nadie de tu equipo tenga que intervenir." },
              { Icon: Sparkles, title: "Informa sobre tratamientos", desc: "Responde dudas frecuentes sobre cada procedimiento, contraindicaciones, duración y postoperatorio con información validada por tu clínica." },
              { Icon: Database, title: "Crea oportunidad en tu CRM", desc: "Registra automáticamente cada lead como oportunidad con su tratamiento de interés, etapa del embudo y datos de contacto listos para cerrar." },
            ].map(({ Icon, title, desc }) => (
              <div key={title} style={{ backgroundColor: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", padding: "28px", transition: "border-color 0.2s" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "var(--primary)")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "var(--border)")}>
                <div style={{ width: 48, height: 48, borderRadius: "8px", backgroundColor: "oklch(0.82 0.13 85 / 0.1)", border: "1px solid oklch(0.82 0.13 85 / 0.3)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "20px" }}>
                  <Icon style={{ width: 24, height: 24, color: "var(--primary)" }} />
                </div>
                <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "18px", marginBottom: "12px" }}>{title}</h3>
                <p style={{ fontSize: "14px", color: "var(--muted-foreground)", lineHeight: 1.6 }}>{desc}</p>
              </div>
            ))}
          </div>
          <p style={{ marginTop: "48px", color: "var(--muted-foreground)", fontStyle: "italic" }}>¿Listo para activarlo?</p>
          <div style={{ marginTop: "16px" }}><CTAButton /></div>
        </div>
      </section>

      {/* CLINVERT IA */}
      <section style={{ padding: "96px 24px", maxWidth: "1152px", margin: "0 auto" }}>
        <div style={{ textAlign: "center" }}>
          <SectionTag>CONOCE A TU NUEVO AGENTE</SectionTag>
          <h2 style={{ marginTop: "32px", fontSize: "clamp(28px, 5vw, 48px)", fontWeight: "bold" }}>Clinvert IA:</h2>
          <h3 style={{ marginTop: "8px", fontSize: "clamp(22px, 4vw, 32px)", fontWeight: "bold" }}>
            El Asistente Que Cierra Más Que Tu Equipo Humano. <span style={{ color: "var(--primary)" }}>Y Nunca Duerme</span> 🌙
          </h3>
          <p style={{ marginTop: "24px", color: "var(--muted-foreground)", maxWidth: "640px", margin: "24px auto 0" }}>
            Entrenado con tu catálogo, tus precios y tu tono. Conversa por WhatsApp, Instagram y web, y deja todo registrado en tu CRM listo para vender.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "40px", alignItems: "center", marginTop: "80px" }}>
          <div>
            <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "24px", marginBottom: "24px" }}>Cotiza, Resuelve y Agenda en Una Sola Conversación</h3>
            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "16px" }}>
              {["Detecta el tratamiento de interés y envía la cotización en segundos.", "Explica beneficios, sesiones recomendadas y postoperatorio con datos de tu clínica.", "Propone horarios y confirma la cita directamente en tu calendario."].map(t => (
                <li key={t} style={{ display: "flex", gap: "12px" }}>
                  <Check style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0, marginTop: 2 }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
          <div style={{ borderRadius: "16px", overflow: "hidden", border: "1px solid var(--border)" }}>
            <img src={aiChatImg} alt="Chat IA" style={{ width: "100%", display: "block" }} loading="lazy" />
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "40px", alignItems: "center", marginTop: "80px" }}>
          <div style={{ borderRadius: "16px", overflow: "hidden", border: "1px solid var(--border)" }}>
            <img src={phonesImg} alt="Analytics" style={{ width: "100%", display: "block" }} loading="lazy" />
          </div>
          <div>
            <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "24px", marginBottom: "24px" }}>Cada Chat Se Convierte En Una Oportunidad Real</h3>
            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "16px" }}>
              {["Crea automáticamente la oportunidad en tu CRM con tratamiento, monto y etapa.", "Asigna el lead al especialista correcto y dispara recordatorios de seguimiento.", "Te entrega el contacto creado CRM y el lead en el nivel apropiado con la información del paciente, tratamiento, agenda y costos."].map(t => (
                <li key={t} style={{ display: "flex", gap: "12px" }}>
                  <Check style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0, marginTop: 2 }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div style={{ textAlign: "center", marginTop: "64px" }}>
          <p style={{ color: "var(--muted-foreground)", fontStyle: "italic", marginBottom: "16px" }}>¿Listo para activarlo?</p>
          <CTAButton />
        </div>
      </section>

      {/* COMPARACIÓN */}
      <section style={{ padding: "96px 24px", backgroundColor: "oklch(0.19 0.025 270 / 0.4)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: "1024px", margin: "0 auto", textAlign: "center" }}>
          <SectionTag>POR QUÉ SOMOS DIFERENTES</SectionTag>
          <h2 style={{ marginTop: "32px", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "bold" }}>Recepcionista Tradicional VS Clinvert IA</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "24px", marginTop: "56px", textAlign: "left" }}>
            <div style={{ backgroundColor: "var(--card)", border: "1px solid var(--border)", borderRadius: "12px", padding: "32px" }}>
              <h3 style={{ color: "var(--destructive)", fontWeight: "bold", fontSize: "20px", marginBottom: "20px" }}>Equipo Tradicional</h3>
              <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px" }}>
                {["Responde solo en horario laboral", "Cotizaciones lentas y manuales", "Olvida hacer seguimiento", "Información inconsistente entre personas", "Dobla horarios y agenda mal", "No registra los leads en el CRM", "Costo fijo mensual elevado", "Se demora días en aprender un nuevo tratamiento", "Imposible escalar sin contratar más gente", "No genera reportes claros"].map(t => (
                  <li key={t} style={{ display: "flex", gap: "12px", fontSize: "14px" }}>
                    <X style={{ width: 20, height: 20, color: "var(--destructive)", flexShrink: 0 }} /><span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div style={{ backgroundColor: "var(--card)", border: "1px solid var(--primary)", borderRadius: "12px", padding: "32px", boxShadow: "var(--shadow-glow)" }}>
              <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "20px", marginBottom: "20px" }}>Clinvert IA</h3>
              <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px" }}>
                {["Responde 24/7 en segundos", "Cotiza al instante y personalizado", "Hace seguimiento automático", "Información unificada y validada", "Agenda directo en tu calendario", "Crea cada lead como oportunidad en tu CRM", "Sin sueldos ni rotación de personal", "Aprende un nuevo tratamiento en minutos", "Escala a miles de chats sin esfuerzo", "Dashboard con métricas en tiempo real"].map(t => (
                  <li key={t} style={{ display: "flex", gap: "12px", fontSize: "14px" }}>
                    <Check style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0 }} /><span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <p style={{ marginTop: "48px", color: "var(--muted-foreground)", fontStyle: "italic" }}>¿Listo para activarlo?</p>
          <div style={{ marginTop: "16px" }}><CTAButton /></div>
        </div>
      </section>

      {/* SOBRE NOSOTROS */}
      <section style={{ padding: "96px 24px", maxWidth: "1024px", margin: "0 auto" }}>
        <h2 style={{ fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "bold", textAlign: "center", marginBottom: "56px" }}>Quiénes Somos</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "40px", alignItems: "center" }}>
          <div style={{ borderRadius: "16px", overflow: "hidden", border: "1px solid var(--border)" }}>
            <img src={foundersImg} alt="Fundadores" style={{ width: "100%", display: "block" }} loading="lazy" />
          </div>
          <div>
            <h3 style={{ color: "var(--primary)", fontWeight: "bold", fontSize: "24px", marginBottom: "24px" }}>Fundadores Juan Carlos y Victor</h3>
            <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "16px" }}>
              {["Somos una empresa de tecnología creada en el año 2010, contamos con experiencia y personal calificado en herramientas de Automatización e Inteligencia Artificial.", "Pioneros en agentes conversacionales que cotizan, agendan y alimentan CRMs en tiempo real.", "Hemos ayudado a clínicas en LATAM a aumentar las consultas de pacientes de manera organizada."].map(t => (
                <li key={t} style={{ display: "flex", gap: "12px" }}>
                  <Check style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0, marginTop: 2 }} /><span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div style={{ textAlign: "center", marginTop: "48px" }}><CTAButton /></div>
      </section>

      {/* FORMULARIO */}
      <ContactForm />

      {/* FAQ */}
      <section style={{ padding: "96px 24px", backgroundColor: "oklch(0.19 0.025 270 / 0.4)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ maxWidth: "768px", margin: "0 auto", textAlign: "center" }}>
          <SectionTag>RESOLVEMOS TUS DUDAS</SectionTag>
          <h2 style={{ marginTop: "32px", fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "bold", marginBottom: "48px" }}>Preguntas Frecuentes</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: "16px", textAlign: "left" }}>
            {[
              { q: "¿Con qué CRMs y calendarios se integra Clinvert IA?", a: "Te entregamos nuestro propio CRM, aunque podríamos integrarlo a futuro con otros CRMs del mercado. Tenemos integración con Google Calendar, Outlook y otras herramientas vía API." },
              { q: "¿Cómo personaliza las cotizaciones para mi clínica?", a: "Cargamos tu catálogo de tratamientos, precios, paquetes y condiciones. La IA arma la cotización con tu tono y la envía por el canal donde te escribió el paciente." },
              { q: "¿Cuánto tiempo toma implementarlo?", a: "Entre 5 y 10 días hábiles. Nosotros nos encargamos del entrenamiento, las integraciones y la puesta en marcha." },
            ].map(({ q, a }) => (
              <details key={q} className="group" style={{ backgroundColor: "var(--card)", border: "1px solid var(--border)", borderRadius: "8px", padding: "20px", cursor: "pointer" }}>
                <summary style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontWeight: 500, listStyle: "none" }}>
                  <span>{q}</span>
                  <ChevronDown style={{ width: 20, height: 20, color: "var(--primary)", flexShrink: 0, transition: "transform 0.2s" }} />
                </summary>
                <p style={{ marginTop: "12px", color: "var(--muted-foreground)", fontSize: "14px", lineHeight: 1.7 }}>{a}</p>
              </details>
            ))}
          </div>
          <div style={{ marginTop: "48px" }}><CTAButton /></div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: "48px 24px", textAlign: "center", fontSize: "12px", color: "var(--muted-foreground)" }}>
        <p>Copyright © 2026 Clinvert IA | Aviso Legal | Política de Privacidad</p>
        <p style={{ marginTop: "8px" }}>info@clinvertia.com</p>
      </footer>
    </div>
  );
}
